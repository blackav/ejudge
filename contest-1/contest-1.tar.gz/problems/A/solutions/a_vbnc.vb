Module ab
Sub Main()
Dim a, b, c as Integer
a = Console.ReadLine()
b = Console.ReadLine()
c = a + b
Console.WriteLine(c)
End Sub
End Module
