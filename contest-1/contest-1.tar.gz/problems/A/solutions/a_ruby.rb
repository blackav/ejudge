a = gets.chomp
b = gets.chomp
puts a.to_i + b.to_i
