import scala.io.StdIn.readInt

object FirstTask {
  def main(args: Array[String]): Unit = {
    println(readInt+readInt)
  }
}
