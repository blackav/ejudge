<?php
list ($a) = fscanf(STDIN, "%d");
list ($b) = fscanf(STDIN, "%d");
print $a + $b . "\n";
?>
