import java.util.*

fun main(args: Array<String>) {
    val sc = Scanner(System.`in`);
    var a: Long = sc.next().toLong();
    var b: Long = sc.next().toLong();
    println(a + b);
}
