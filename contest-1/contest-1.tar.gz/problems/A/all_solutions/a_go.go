package main
import "fmt"

func main(){
    var a, b int64
    fmt.Scan(&a)
    fmt.Scan(&b)
    fmt.Printf("%d\n", a + b)
}
