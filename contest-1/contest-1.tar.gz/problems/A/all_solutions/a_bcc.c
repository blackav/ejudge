#include <stdio.h>

int main(void)
{
  long a, b;

  scanf("%ld%ld", &a, &b);
  printf("%ld\n", a + b);
  return 0;
}
