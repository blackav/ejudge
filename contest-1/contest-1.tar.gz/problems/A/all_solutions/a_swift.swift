import Foundation

let a = readLine()
let b = readLine()

let a1 = Int(a!)
let b1 = Int(b!)

let c = a1! + b1!

print (c)
