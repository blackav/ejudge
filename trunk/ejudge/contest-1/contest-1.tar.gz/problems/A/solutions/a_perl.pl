chomp($a = <STDIN>);
chomp($b = <STDIN>);
print $a + $b;
