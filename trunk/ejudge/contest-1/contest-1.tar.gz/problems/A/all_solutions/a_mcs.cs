using System;

class MainClass
{
	static void Main(string[] args)
	{
		int a = Int32.Parse(Console.ReadLine());
		int b = Int32.Parse(Console.ReadLine());
		Console.WriteLine("{0}", a + b);
	}
}
