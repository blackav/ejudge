#include <iostream.h>
int main()
{
  long a, b;
  cin >> a;
  cin >> b;
  cout << a + b;
  return 0;
}
