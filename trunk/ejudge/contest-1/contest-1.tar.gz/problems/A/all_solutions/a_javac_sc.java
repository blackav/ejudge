import java.io.*;
import java.util.Scanner;

public final class a_b
{
  public static void main(String args[]) throws Exception
  {
    Scanner s = new Scanner(System.in);
    int a, b;

    a = s.nextInt();
    b = s.nextInt();
    System.out.println(a + b);
  }
}
